(function (){
	'use strict';

	$(window).load(function(){
		$('.flexslider').flexslider({
			prevText:'',
			nextText: '',
		});
	});
	
})();